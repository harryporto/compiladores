
d || a |= b}{
print(1);
}
}
